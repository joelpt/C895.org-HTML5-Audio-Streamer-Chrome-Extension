Git repository: https://github.com/joelpt/C895.org-HTML5-Audio-Streamer-Chrome-Extension

Chrome extension: https://chrome.google.com/webstore/detail/c895org-html5-live-player/caikemhebfaieainegdbfiibbipihpol